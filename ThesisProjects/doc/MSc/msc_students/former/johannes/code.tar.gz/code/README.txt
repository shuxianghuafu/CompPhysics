1. just compile the whole simulator with 'make' at the root directory
2. you can simply run the simulator with the executable './project.app'
