This is the directory where libblitz.a should reside.
