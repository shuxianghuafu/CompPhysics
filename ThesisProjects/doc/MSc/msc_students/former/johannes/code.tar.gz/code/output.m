     %%%%%%%%% Input Parameters %%%%%%%%   
d= 2           %%% Dimension of the system
R= 2           %%% Maximum energy level to consider
lambda= 1.00000           %%% Strength of confinement
epsilon= 1e-10           %%% Precision of the HF algorithm


Total_Energy= 28.00000000000000000000% iter #001 
Total_Energy= 28.00000000000000000000% iter #002 


E = 28.00000000000000000000     % Hartree-Fock energy of the quantum dot


%%%%%%%%   Coefficients of the HF orbitals (one column per particle, one row per single particle state) %%%%%%%%
HForbitals = [1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0000000 
];


%%%%%%%%   Effective potential (row and column corresponding to single particle states in the order given by singleParticleOrbitals, so sorted by identical angular momentum) %%%%%%%%
U = [7.1527029 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 7.1527029 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 7.7940473 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 7.7940473 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 8.6165347 0.0000000 1.0574838 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 8.6165347 0.0000000 1.0574838 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 1.0574838 0.0000000 7.2555139 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 1.0574838 0.0000000 7.2555139 0.0000000 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 7.7940473 0.0000000 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 7.7940473 0.0000000 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 7.1527029 0.0000000 
0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 0.0000000 7.1527029 
];


%%%%%%%% Table of states with their quantum numbers, grouped by identical angular momentum %%%%%%%%
NbStates= 12;   % Total number of states
states= sparse(12,3);
states(1,1)=0; % ---state #0 |n=0,ml=-2,ms=-1>
states(1,2)=-2; % ---state #0 |n=0,ml=-2,ms=-1>
states(1,3)=-1; % ---state #0 |n=0,ml=-2,ms=-1>
states(2,1)=0; % ---state #1 |n=0,ml=-2,ms=1>
states(2,2)=-2; % ---state #1 |n=0,ml=-2,ms=1>
states(2,3)=1; % ---state #1 |n=0,ml=-2,ms=1>
states(3,1)=0; % ---state #2 |n=0,ml=-1,ms=-1>
states(3,2)=-1; % ---state #2 |n=0,ml=-1,ms=-1>
states(3,3)=-1; % ---state #2 |n=0,ml=-1,ms=-1>
states(4,1)=0; % ---state #3 |n=0,ml=-1,ms=1>
states(4,2)=-1; % ---state #3 |n=0,ml=-1,ms=1>
states(4,3)=1; % ---state #3 |n=0,ml=-1,ms=1>
states(5,1)=0; % ---state #4 |n=0,ml=0,ms=-1>
states(5,2)=0; % ---state #4 |n=0,ml=0,ms=-1>
states(5,3)=-1; % ---state #4 |n=0,ml=0,ms=-1>
states(6,1)=0; % ---state #5 |n=0,ml=0,ms=1>
states(6,2)=0; % ---state #5 |n=0,ml=0,ms=1>
states(6,3)=1; % ---state #5 |n=0,ml=0,ms=1>
states(7,1)=1; % ---state #6 |n=1,ml=0,ms=-1>
states(7,2)=0; % ---state #6 |n=1,ml=0,ms=-1>
states(7,3)=-1; % ---state #6 |n=1,ml=0,ms=-1>
states(8,1)=1; % ---state #7 |n=1,ml=0,ms=1>
states(8,2)=0; % ---state #7 |n=1,ml=0,ms=1>
states(8,3)=1; % ---state #7 |n=1,ml=0,ms=1>
states(9,1)=0; % ---state #8 |n=0,ml=1,ms=-1>
states(9,2)=1; % ---state #8 |n=0,ml=1,ms=-1>
states(9,3)=-1; % ---state #8 |n=0,ml=1,ms=-1>
states(10,1)=0; % ---state #9 |n=0,ml=1,ms=1>
states(10,2)=1; % ---state #9 |n=0,ml=1,ms=1>
states(10,3)=1; % ---state #9 |n=0,ml=1,ms=1>
states(11,1)=0; % ---state #10 |n=0,ml=2,ms=-1>
states(11,2)=2; % ---state #10 |n=0,ml=2,ms=-1>
states(11,3)=-1; % ---state #10 |n=0,ml=2,ms=-1>
states(12,1)=0; % ---state #11 |n=0,ml=2,ms=1>
states(12,2)=2; % ---state #11 |n=0,ml=2,ms=1>
states(12,3)=1; % ---state #11 |n=0,ml=2,ms=1>


%%%%%%%% Table of couples of states with the same {M,S} %%%%%%%%

StateCouples_0000=sparse(2,8);
%---channel #0 {M=0 S=0}: (0,11) (1,10) (2,9) (3,8) (4,5) (4,7) (5,6) (6,7) 
StateCouples_0000(1,1)= 0;StateCouples_0000(2,1)= 11;
StateCouples_0000(1,2)= 1;StateCouples_0000(2,2)= 10;
StateCouples_0000(1,3)= 2;StateCouples_0000(2,3)= 9;
StateCouples_0000(1,4)= 3;StateCouples_0000(2,4)= 8;
StateCouples_0000(1,5)= 4;StateCouples_0000(2,5)= 5;
StateCouples_0000(1,6)= 4;StateCouples_0000(2,6)= 7;
StateCouples_0000(1,7)= 5;StateCouples_0000(2,7)= 6;
StateCouples_0000(1,8)= 6;StateCouples_0000(2,8)= 7;

StateCouples_0001=sparse(2,6);
%---channel #1 {M=0 S=1}: (0,10) (1,11) (2,8) (3,9) (4,6) (5,7) 
StateCouples_0001(1,1)= 0;StateCouples_0001(2,1)= 10;
StateCouples_0001(1,2)= 1;StateCouples_0001(2,2)= 11;
StateCouples_0001(1,3)= 2;StateCouples_0001(2,3)= 8;
StateCouples_0001(1,4)= 3;StateCouples_0001(2,4)= 9;
StateCouples_0001(1,5)= 4;StateCouples_0001(2,5)= 6;
StateCouples_0001(1,6)= 5;StateCouples_0001(2,6)= 7;

StateCouples_0002=sparse(2,12);
%---channel #2 {M=1 S=0}: (0,9) (1,8) (2,5) (2,7) (2,11) (3,4) (3,6) (3,10) (4,9) (5,8) (6,9) (7,8) 
StateCouples_0002(1,1)= 0;StateCouples_0002(2,1)= 9;
StateCouples_0002(1,2)= 1;StateCouples_0002(2,2)= 8;
StateCouples_0002(1,3)= 2;StateCouples_0002(2,3)= 5;
StateCouples_0002(1,4)= 2;StateCouples_0002(2,4)= 7;
StateCouples_0002(1,5)= 2;StateCouples_0002(2,5)= 11;
StateCouples_0002(1,6)= 3;StateCouples_0002(2,6)= 4;
StateCouples_0002(1,7)= 3;StateCouples_0002(2,7)= 6;
StateCouples_0002(1,8)= 3;StateCouples_0002(2,8)= 10;
StateCouples_0002(1,9)= 4;StateCouples_0002(2,9)= 9;
StateCouples_0002(1,10)= 5;StateCouples_0002(2,10)= 8;
StateCouples_0002(1,11)= 6;StateCouples_0002(2,11)= 9;
StateCouples_0002(1,12)= 7;StateCouples_0002(2,12)= 8;

StateCouples_0003=sparse(2,12);
%---channel #3 {M=1 S=1}: (0,8) (1,9) (2,4) (2,6) (2,10) (3,5) (3,7) (3,11) (4,8) (5,9) (6,8) (7,9) 
StateCouples_0003(1,1)= 0;StateCouples_0003(2,1)= 8;
StateCouples_0003(1,2)= 1;StateCouples_0003(2,2)= 9;
StateCouples_0003(1,3)= 2;StateCouples_0003(2,3)= 4;
StateCouples_0003(1,4)= 2;StateCouples_0003(2,4)= 6;
StateCouples_0003(1,5)= 2;StateCouples_0003(2,5)= 10;
StateCouples_0003(1,6)= 3;StateCouples_0003(2,6)= 5;
StateCouples_0003(1,7)= 3;StateCouples_0003(2,7)= 7;
StateCouples_0003(1,8)= 3;StateCouples_0003(2,8)= 11;
StateCouples_0003(1,9)= 4;StateCouples_0003(2,9)= 8;
StateCouples_0003(1,10)= 5;StateCouples_0003(2,10)= 9;
StateCouples_0003(1,11)= 6;StateCouples_0003(2,11)= 8;
StateCouples_0003(1,12)= 7;StateCouples_0003(2,12)= 9;

StateCouples_0004=sparse(2,10);
%---channel #4 {M=2 S=0}: (0,5) (0,7) (1,4) (1,6) (2,3) (4,11) (5,10) (6,11) (7,10) (8,9) 
StateCouples_0004(1,1)= 0;StateCouples_0004(2,1)= 5;
StateCouples_0004(1,2)= 0;StateCouples_0004(2,2)= 7;
StateCouples_0004(1,3)= 1;StateCouples_0004(2,3)= 4;
StateCouples_0004(1,4)= 1;StateCouples_0004(2,4)= 6;
StateCouples_0004(1,5)= 2;StateCouples_0004(2,5)= 3;
StateCouples_0004(1,6)= 4;StateCouples_0004(2,6)= 11;
StateCouples_0004(1,7)= 5;StateCouples_0004(2,7)= 10;
StateCouples_0004(1,8)= 6;StateCouples_0004(2,8)= 11;
StateCouples_0004(1,9)= 7;StateCouples_0004(2,9)= 10;
StateCouples_0004(1,10)= 8;StateCouples_0004(2,10)= 9;

StateCouples_0005=sparse(2,8);
%---channel #5 {M=2 S=1}: (0,4) (0,6) (1,5) (1,7) (4,10) (5,11) (6,10) (7,11) 
StateCouples_0005(1,1)= 0;StateCouples_0005(2,1)= 4;
StateCouples_0005(1,2)= 0;StateCouples_0005(2,2)= 6;
StateCouples_0005(1,3)= 1;StateCouples_0005(2,3)= 5;
StateCouples_0005(1,4)= 1;StateCouples_0005(2,4)= 7;
StateCouples_0005(1,5)= 4;StateCouples_0005(2,5)= 10;
StateCouples_0005(1,6)= 5;StateCouples_0005(2,6)= 11;
StateCouples_0005(1,7)= 6;StateCouples_0005(2,7)= 10;
StateCouples_0005(1,8)= 7;StateCouples_0005(2,8)= 11;

StateCouples_0006=sparse(2,4);
%---channel #6 {M=3 S=0}: (0,3) (1,2) (8,11) (9,10) 
StateCouples_0006(1,1)= 0;StateCouples_0006(2,1)= 3;
StateCouples_0006(1,2)= 1;StateCouples_0006(2,2)= 2;
StateCouples_0006(1,3)= 8;StateCouples_0006(2,3)= 11;
StateCouples_0006(1,4)= 9;StateCouples_0006(2,4)= 10;

StateCouples_0007=sparse(2,4);
%---channel #7 {M=3 S=1}: (0,2) (1,3) (8,10) (9,11) 
StateCouples_0007(1,1)= 0;StateCouples_0007(2,1)= 2;
StateCouples_0007(1,2)= 1;StateCouples_0007(2,2)= 3;
StateCouples_0007(1,3)= 8;StateCouples_0007(2,3)= 10;
StateCouples_0007(1,4)= 9;StateCouples_0007(2,4)= 11;

StateCouples_0008=sparse(2,2);
%---channel #8 {M=4 S=0}: (0,1) (10,11) 
StateCouples_0008(1,1)= 0;StateCouples_0008(2,1)= 1;
StateCouples_0008(1,2)= 10;StateCouples_0008(2,2)= 11;

StateCouples_0009=sparse(2,0);
%---channel #9 {M=4 S=1}: 
