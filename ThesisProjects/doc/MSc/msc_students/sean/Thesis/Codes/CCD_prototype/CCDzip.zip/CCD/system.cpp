#include "system.h"

System::System()
{
}
