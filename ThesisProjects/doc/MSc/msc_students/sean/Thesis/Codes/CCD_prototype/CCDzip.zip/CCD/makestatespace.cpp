#include "makestatespace.h"

MakeStateSpace::MakeStateSpace()
{

};
