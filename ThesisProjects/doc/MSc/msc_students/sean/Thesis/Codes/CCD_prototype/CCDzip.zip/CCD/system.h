#ifndef SYSTEM_H
#define SYSTEM_H

class System
{
public:
    System();
};

#endif // SYSTEM_H
